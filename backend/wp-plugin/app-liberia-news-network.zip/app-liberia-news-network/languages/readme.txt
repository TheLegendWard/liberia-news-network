Create a file POT, PO and MO using POEdit or Loco Translate Plugin, 
then rename accordance with textdomain used by the plugin, as follows:
* app_liberia-news-network-de_DE.po
* app_liberia-news-network-id_ID.po
* app_liberia-news-network_ES.po
* app_liberia-news-network-en_US.po
* app_liberia-news-network-de_DE.mo
* app_liberia-news-network-id_ID.mo
* app_liberia-news-network-es_ES.mo
* app_liberia-news-network-en_US.mo
Download:
* http://wordpress.org/extend/plugins/loco-translate
* http://poedit.net/download
